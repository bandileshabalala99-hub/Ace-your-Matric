import type { Metadata } from "next"
import { DownloadsView } from "@/components/downloads-view"

export const metadata: Metadata = {
  title: "My Downloads — Ace Your Matric",
  description: "Past papers saved on your phone for offline study.",
}

export default function DownloadsPage() {
  return <DownloadsView />
}
